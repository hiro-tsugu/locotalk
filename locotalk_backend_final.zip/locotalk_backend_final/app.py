from flask import Flask
from flask_cors import CORS
from routes.municipalities import municipality_bp
from routes.reports import report_bp

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "http://localhost:3000"}}, supports_credentials=True)

app.register_blueprint(municipality_bp)
app.register_blueprint(report_bp)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
