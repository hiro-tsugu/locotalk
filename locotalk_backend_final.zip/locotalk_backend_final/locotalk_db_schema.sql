CREATE DATABASE locotalk_db;

USE locotalk_db;

-- users テーブル
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at DATETIME
);

-- images テーブル
CREATE TABLE images (
    id INT PRIMARY KEY AUTO_INCREMENT,
    image_data LONGBLOB,
    created_at DATETIME
);

-- municipalities テーブル
CREATE TABLE municipalities (
  id VARCHAR(10) PRIMARY KEY,
  prefecture VARCHAR(50),
  jurisdiction VARCHAR(50),
  city VARCHAR(50),
  sub_city VARCHAR(50),
  name VARCHAR(100),
  created_at DATETIME
);

-- reports テーブル
CREATE TABLE reports (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    municipality_id VARCHAR(10) NOT NULL,
    title VARCHAR(200) NOT NULL,
    body TEXT NOT NULL,
    image_id INT,
    created_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (municipality_id) REFERENCES municipalities(id) ON DELETE CASCADE,
    FOREIGN KEY (image_id) REFERENCES images(id) ON DELETE SET NULL
);

-- save_requests テーブル
CREATE TABLE save_requests (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    municipality_id VARCHAR(10) NOT NULL,
    is_saved TINYINT(1) NOT NULL,
    updated_at DATETIME,
    UNIQUE KEY unique_save (user_id, municipality_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (municipality_id) REFERENCES municipalities(id) ON DELETE CASCADE
);

SHOW tables;

DESCRIBE users;

DESCRIBE images;

DESCRIBE municipalities;

DESCRIBE reports;

DESCRIBE save_requests;
